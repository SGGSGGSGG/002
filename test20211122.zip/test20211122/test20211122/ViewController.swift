//
//  ViewController.swift
//  test2021-11-22
//
//  Created by SGG Fang on 2021/11/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var inputText: UITextField!
    @IBOutlet var putputText:UILabel!
    
    var received:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "changeUSER"{
            //pass data
            let des = segue.destination as! SecondViewController
            des.received = inputText.text
            
        }
    }
    @IBAction func backTo(segue:UIStoryboardSegue){
        let src = segue.source as!SecondViewController
        received = src.inputText.text
        putputText.text = received
        dismiss(animated: true, completion: nil)
    }
}

